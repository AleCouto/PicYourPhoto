namespace PicYourPhoto.Models
{
    public class ImageInfo
    {
        public string? Path { get; set; }
        public bool? IsSelected { get; set; }
        public string? Data { get; set; }

    }
}