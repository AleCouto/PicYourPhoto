﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using Microsoft.JSInterop;
using pAp.Models;
using System.Text.Json;

namespace pAp.Services
{
    public class ImageService
    {
        private readonly IJSRuntime _jsRuntime;
        public List<ImageInfo> Images { get; private set; } = [];
        public string? SuccessMessage { get; private set; }

        public ImageService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public void ClearMessage()
        {
            SuccessMessage = string.Empty;
        }

        public async Task LoadImages(InputFileChangeEventArgs e)
        {
            try
            {
                var imageFiles = e.GetMultipleFiles();
                Images.Clear();

                foreach (var file in imageFiles)
                {
                    var base64Image = await ConvertToBase64(file);
                    Images.Add(new ImageInfo { ImgData = $"data:{file.ContentType};base64,{base64Image}", ImgName = file.Name, IsSelected = false });
                }
                await SaveImagesToLocalStorage();
                SuccessMessage = "Imagens carregadas e salvas com sucesso!";
            }
            catch (Exception)
            {
                return;
            }
        }

        private static async Task<string> ConvertToBase64(IBrowserFile file)
        {
            using var stream = file.OpenReadStream(maxAllowedSize: 10 * 1024 * 1024); // Max file size 10MB
            using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);
            var bytes = memoryStream.ToArray();
            return Convert.ToBase64String(bytes);
        }

        private async Task SaveImagesToLocalStorage()
        {
            var jsonImages = JsonSerializer.Serialize(Images);
            await _jsRuntime.InvokeVoidAsync("localStorage.setItem", "uploadedImages", jsonImages);
        }

        public async Task LoadImagesFromLocalStorage()
        {
            var jsonImages = await _jsRuntime.InvokeAsync<string>("localStorage.getItem", "uploadedImages");
            if (!string.IsNullOrEmpty(jsonImages))
            {
                Images = JsonSerializer.Deserialize<List<ImageInfo>>(jsonImages) ?? new List<ImageInfo>();
            }
        }
    }
}
