﻿namespace pAp.Models
{
    public class ImageInfo
    {
        public string? ImgData { get; set; }
        public string? ImgName { get; set; }
        public bool? IsSelected { get; set; }
    }
}
