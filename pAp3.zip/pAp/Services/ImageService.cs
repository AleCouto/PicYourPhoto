﻿using Microsoft.AspNetCore.Components.Forms;
using pAp.Models;

namespace pAp.Services
{
    public class ImageService
    {
        public List<ImageInfo> Images { get; private set; } = [];
        public string? SuccessMessage { get; private set; }

        public void ClearMessage()
        {
            SuccessMessage = string.Empty;
        }

        public async Task LoadImages(InputFileChangeEventArgs e)
        {
            var imageFiles = e.GetMultipleFiles();
            Images.Clear();

            foreach (var file in imageFiles)
            {
                var base64Image = await ConvertToBase64(file);
                Images.Add(new ImageInfo { ImgData = $"data:{file.ContentType};base64,{base64Image}", ImgName = file.Name, IsSelected = false });
            }

            SuccessMessage = "Imagens carregadas com sucesso!";
        }

        private static async Task<string> ConvertToBase64(IBrowserFile file)
        {
            using var stream = file.OpenReadStream(maxAllowedSize: 10 * 1024 * 1024); // Max file size 10MB
            using var memoryStream = new MemoryStream();
            await stream.CopyToAsync(memoryStream);
            var bytes = memoryStream.ToArray();
            return Convert.ToBase64String(bytes);
        }
    }
}
