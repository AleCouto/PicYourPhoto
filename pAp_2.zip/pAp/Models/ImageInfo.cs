﻿namespace pAp.Models
{
    public class ImageInfo
    {
        public string? Data { get; set; }
        public string? Path { get; set; }
        public bool? IsSelected { get; set; }
    }
}
